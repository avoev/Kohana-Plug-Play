-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 10, 2010 at 11:10 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kohana`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `name`, `desc`, `img`) VALUES
(1, 'Article (grammar)', 'An article (abbreviated art) is a word that combines with a noun to indicate the type of reference being made by the noun. Articles specify the grammatical definiteness of the noun, in some languages extending to volume or numerical scope. The articles in the English language are the and a/an. ''An'' and ''a'' are modern forms of the Old English ''an'', which in Anglian dialects was the number ''one'' (compare ''on'', in Saxon dialects) and survived into Modern Scots as the number ''ane''. Both ''on'' (respelled ''one'' by the Normans) and ''an'' survived into Modern English, with ''one'' used as the number and ''an'' (''a'', before nouns that begin with a consonant sound) as an indefinite article.', ''),
(2, 'Island Fox', 'The Island Fox (Urocyon littoralis) is a small fox that is native to six of the eight Channel Islands of California. There are six subspecies of the fox, each unique to the island it lives on, reflecting its evolutionary history. Other names for the Island Fox include Coast Fox, Short-Tailed Fox, Island Gray Fox, Channel Islands Fox, Channel Islands Gray Fox, California Channel Island Fox and Insular Gray Fox.', ''),
(3, 'Red-winged Fairywren', 'The Red-winged Fairywren (Malurus elegans) is a species of passerine bird in the Maluridae family. It is sedentary and endemic to the southwestern corner of Western Australia. Exhibiting a high degree of sexual dimorphism, the male adopts a brilliantly coloured breeding plumage, with an iridescent silvery-blue crown, ear coverts and upper back, red shoulders, contrasting with a black throat, grey-brown tail and wings and pale underparts. Non-breeding males, females and juveniles have predominantly grey-brown plumage, though males may bear isolated blue and black feathers. No separate subspecies are recognised. Similar in appearance and closely related to the Variegated Fairywren (M. lamberti) and the Blue-breasted Fairywren (M. pulcherrimus), it is regarded as a separate species as no intermediate forms have been recorded where ranges overlap. Though the Red-winged Fairywren is locally common, there is evidence of a decline in numbers.', ''),
(4, 'Thoroughbred', 'The Thoroughbred is a horse breed best known for its use in horse racing. Although the word thoroughbred is sometimes used to refer to any breed of purebred horse, it technically refers only to the Thoroughbred breed. Thoroughbreds are considered a "hot-blooded" horse, known for their agility, speed and spirit.', ''),
(5, 'Pied Currawong', 'The Pied Currawong (Strepera graculina) is a medium-sized black passerine bird native to eastern Australia and Lord Howe Island. One of three currawong species in the genus Strepera, it is closely related to the butcherbirds and Australian Magpie of the family Artamidae. Six subspecies are recognised. It is a robust crow-like bird averaging around 48 cm (19 in) in length, black or sooty grey-black in plumage with white undertail and wing patches, yellow irises, and a heavy bill. The male and female are similar in appearance. Known for its melodious calls, the species'' name currawong is of indigenous origin.', ''),
(6, 'Short-beaked Echidna', 'The Short-beaked Echidna (Tachyglossus aculeatus), also known as the Spiny Anteater because of its diet of ants and termites, is one of four living species of echidna and the only member of the genus Tachyglossus. The Short-beaked Echidna is covered in fur and spines and has a distinctive snout and a specialized tongue, which it uses to catch its prey at a great speed. Like the other extant monotremes, the Short-beaked Echidna lays eggs; the monotremes are the only group of mammals to do so.', '');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'login', 'Login privileges, granted after account confirmation'),
(2, 'admin', 'Administrative user, has access to everything.');

-- --------------------------------------------------------

--
-- Table structure for table `roles_users`
--

CREATE TABLE IF NOT EXISTS `roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `roles_users`
--

INSERT INTO `roles_users` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` char(50) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `logins`, `last_login`) VALUES
(1, 'email@username.com', 'username', 'd577b334973efc0c83a22f3000f7897c841b0273bf9d2fe3c0', 1, 1292051374);

-- --------------------------------------------------------

--
-- Table structure for table `user_tokens`
--

CREATE TABLE IF NOT EXISTS `user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(32) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user_tokens`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `roles_users`
--
ALTER TABLE `roles_users`
  ADD CONSTRAINT `roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_tokens`
--
ALTER TABLE `user_tokens`
  ADD CONSTRAINT `user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
